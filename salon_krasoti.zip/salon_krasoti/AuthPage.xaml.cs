﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace salon_krasoti
{
    public partial class AuthPage : Page
    {

        private int _failedAttempts = 0;
        private string _generatedCaptcha;

        public AuthPage()
        {
            InitializeComponent();
            captchaPanel.Visibility = Visibility.Collapsed;
        }

        public bool Auth(string login, string password)
        {
            if (string.IsNullOrEmpty(login)) return false;
            if (string.IsNullOrEmpty(password)) return false;

            string passwordHash = GetHash(password);

            using (var db = new Entities())
            {
                return db.UserAccounts
                    .AsNoTracking()
                    .Any(u => u.Username == login &&
                             u.PasswordHash == passwordHash);
            }
        }

        public UserAccounts GetAuthenticatedUser(string login, string password)
        {
            if (string.IsNullOrEmpty(login)) return null;
            if (string.IsNullOrEmpty(password)) return null;

            string passwordHash = GetHash(password);

            using (var db = new Entities())
            {
                return db.UserAccounts
                    .AsNoTracking()
                    .FirstOrDefault(u => u.Username == login &&
                                       u.PasswordHash == passwordHash);
            }
        }

        private void signInButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка капчи после 3 неудачных попыток
            if (_failedAttempts >= 3)
            {
                if (captchaText.Text != _generatedCaptcha)
                {
                    MessageBox.Show("Неверная капча!");
                    GenerateNewCaptcha();
                    return;
                }
            }

            var user = GetAuthenticatedUser(loginTextBox.Text, passwordText.Password);

            if (user == null)
            {
                _failedAttempts++;

                if (_failedAttempts >= 3)
                {
                    captchaPanel.Visibility = Visibility.Visible;
                    GenerateNewCaptcha();
                }

                MessageBox.Show("Неверный логин или пароль!");
                return;
            }

            OpenUserWindow(user);
        }

        private void OpenUserWindow(UserAccounts user)
        {
            Window newWindow = null;

            using (var db = new Entities())
            {
                switch (user.RoleID)
                {
                    case 1: // Администратор
                        newWindow = new AdminWindow(user);
                        break;
                    case 2: // Сотрудник
                        var employee = db.Employees
                            .FirstOrDefault(emp => emp.EmployeeID == user.EmployeeID);
                        if (employee != null)
                            newWindow = new EmployeeWindow(employee);
                        break;
                    case 3: // Клиент
                        newWindow = new ClientWindow(user);
                        break;
                }
            }

            if (newWindow != null)
            {
                Application.Current.MainWindow?.Close();
                newWindow.Show();
            }
            else
            {
                MessageBox.Show("Ошибка определения роли пользователя!");
            }
        }

        private void GenerateNewCaptcha()
        {
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            var random = new Random();
            _generatedCaptcha = new string(Enumerable.Repeat(chars, 6)
                .Select(s => s[random.Next(s.Length)]).ToArray());

            captchaDisplay.Text = _generatedCaptcha;
        }

        public static string GetHash(string password)
        {
            using (var sha1 = SHA1.Create())
            {
                return string.Concat(sha1
                    .ComputeHash(Encoding.UTF8.GetBytes(password))
                    .Select(b => b.ToString("X2")));
            }
        }

        private void NavigateToReg_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new RegPage());
        }
    }
}